package com.example.twoPointAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwoPointApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoPointApiApplication.class, args);
	}

}
